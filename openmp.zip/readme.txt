Homework OpenMP

1) For matmul.c add an OpenMP directive (e.g pragma) 
   to parallelize and speedup the code.

2) For mandel.c add one or more OpenMP directives 
   (e.g. pragma) to parallelize and speedup the code.
