C
C     parameters for program brem
C
      integer EMAX              ! maximum incident energy
      integer BINMEV            ! bins per MeV
      parameter (EMAX=1000,BINMEV=10)
